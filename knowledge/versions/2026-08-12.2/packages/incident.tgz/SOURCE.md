# Source and License

This sanitized theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/d9a60077-619a-4cb7-95ed-0c428c2b51ed

Excluded from this install package: screenshots, promotional images, logos, proprietary icons, and font binaries.
