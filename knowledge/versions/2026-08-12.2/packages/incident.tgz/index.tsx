import './style.css';

const colors = ["#efefef","#000000","#ffffff","#161618","#ff492c","#dadada","#cccccc","#f25533","#e4d9c8","#0770e3","#f1641e","#ff66f4"];
const title = "Incident";
const description = "Explore Incident's light SaaS design system: Canvas White #ffffff, Platinum Mist #efefef colors, Times, Arial typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
