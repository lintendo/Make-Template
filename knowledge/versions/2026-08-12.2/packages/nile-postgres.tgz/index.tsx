import './style.css';

const colors = ["#0e0e0e","#1c1c1c","#6fe2ff","#ffffff","#d3d3d3","#3f3f3f","#2f3336","#ffba6a","#d8d3ff","#2b2b2b","#a1a1aa","#9cdcfe"];
const title = "Nile Postgres";
const description = "Explore Nile Postgres's dark Dev Tools design system: Midnight Ink #0e0e0e, Carbon Panel #1c1c1c colors, aeonik, aeonik typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
