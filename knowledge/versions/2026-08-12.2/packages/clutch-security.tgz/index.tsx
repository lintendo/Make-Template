import './style.css';

const colors = ["#e5e7eb","#000000","#ffffff","#dfdfdf","#d9d9d9","#c9c9c9","#f9fafb","#6e6e6e","#878787","#004dff","#e6c5f7","#d9e4ff"];
const title = "Clutch Security";
const description = "Explore Clutch Security's light Fintech design system: Canvas White #ffffff, Ink Black #000000 colors, Inter, PP Radio Grotesk typography, and DESIGN.md for...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
