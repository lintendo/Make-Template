import './style.css';

const colors = ["#000000","#76b900","#0046a4","#5a8d00","#ffffff","#f7f7f7","#1a1a1a","#cccccc","#5e5e5e","#757575","#898989","#a7a7a7"];
const title = "Nvidia";
const description = "GPU computing. Green-black energy, technical power aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
