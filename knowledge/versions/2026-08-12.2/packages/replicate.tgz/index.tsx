import './style.css';

const colors = ["#202020","#ea2804","#c01f00","#ffffff","#3a3a3a","#575757","#646464","#8d8d8d","#bbbbbb","#fcfcfc","#f9f7f3","#f3f0e8"];
const title = "Replicate";
const description = "Run ML models via API. Clean white canvas, code-forward.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
