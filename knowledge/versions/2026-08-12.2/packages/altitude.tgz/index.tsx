import './style.css';

const colors = ["#181818","#262626","#eeeeee","#ffffff","#e4e4e4","#323232","#1f1f1f","#e7e5e4","#111111","#5e5d59","#a4a19b","#585858"];
const title = "Altitude";
const description = "Explore Altitude's dark Fintech design system: Deep Charcoal #181818, Graphite #262626 colors, Libre Baskerville, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
