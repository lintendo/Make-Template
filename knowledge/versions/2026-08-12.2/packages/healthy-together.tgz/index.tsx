import './style.css';

const colors = ["#101722","#f9f0ff","#4541fe","#d9c6ff","#ffffff","#6c6c7a","#3f424e","#fe0f83","#141414","#000000","#040723","#140f33"];
const title = "Healthy Together";
const description = "Explore Healthy Together's mixed Fintech design system: Midnight Ink #101722, Canvas Ice #f9f0ff colors, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
