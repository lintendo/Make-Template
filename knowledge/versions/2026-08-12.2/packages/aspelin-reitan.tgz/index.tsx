import './style.css';

const colors = ["#ffebd0","#000000","#fff8e9","#fee197","#2f2116","#4f3622","#987f61","#8f534e","#ffffff","#f0f1ef","#333333","#d7d7d7"];
const title = "Aspelin Reitan";
const description = "Explore Aspelin Reitan's dark Other design system: Midnight Caviar #000000, Amber Sands #ffebd0 colors, ModernEra typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
