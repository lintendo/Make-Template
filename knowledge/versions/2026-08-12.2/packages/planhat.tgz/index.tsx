import './style.css';

const colors = ["#121211","#000000","#ffffff","#575551","#958d7e","#22c55e","#f6f6f8","#1a1a1a","#666666","#999999","#f2f2f2","#0c0a09"];
const title = "Planhat";
const description = "Explore Planhat's light SaaS design system: Twilight Ink #000000, Canvas White #ffffff colors, Geigy LL Duplex Var Variable Reg, Inter typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
