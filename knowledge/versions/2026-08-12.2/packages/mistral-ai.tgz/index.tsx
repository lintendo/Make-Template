import './style.css';

const colors = ["#fa520f","#cc3a05","#1f1f1f","#ffffff","#ffd06a","#ffb83e","#ffa110","#ff8105","#ff8a00","#ffd900","#fff8e0","#fffaeb"];
const title = "Mistral AI";
const description = "Open-weight LLM provider. French-engineered minimalism, purple-toned.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
