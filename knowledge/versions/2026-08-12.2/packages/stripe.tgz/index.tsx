import './style.css';

const colors = ["#533afd","#4434d4","#0d253d","#2e2b8c","#665efd","#b9b9f9","#1c1e54","#273951","#64748d","#61718a","#ffffff","#f6f9fc"];
const title = "Stripe";
const description = "Payment infrastructure. Signature purple gradients, weight-300 elegance.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
