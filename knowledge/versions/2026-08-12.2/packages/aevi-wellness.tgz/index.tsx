import './style.css';

const colors = ["#231f20","#000000","#ffffff","#d5e0ea","#a3bfdb","#134fc2","#006fcf","#ffa8cd","#5a31f4","#fff48d","#005b9a","#0e73b9"];
const title = "Aevi Wellness";
const description = "Explore Aevi Wellness's light E-commerce design system: Canvas White #ffffff, Charcoal Text #231f20 colors, Primary Font, Custom Font 1 typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
