import './style.css';

const colors = ["#303030","#000000","#ffffff","#fffffb","#e7e7e7","#c0c0c0","#707070","#ff7840","#afafaf","#1d1d1d","#d6d5d0","#ff6105"];
const title = "SAPGOODENERGY";
const description = "Explore SAPGOODENERGY's light E-commerce design system: Midnight Ink #000000, Canvas White #ffffff colors, GT Pressura LC Standard, Helvetica Neue LT Std...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
