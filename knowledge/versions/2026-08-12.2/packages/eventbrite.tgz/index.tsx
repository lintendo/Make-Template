import './style.css';

const colors = ["#f8f7fa","#39364f","#ffffff","#3659e3","#dbdae3","#1e0a3c","#bec0c6","#000000","#eeedf2","#585163","#dee5ff","#d2d4d6"];
const title = "Eventbrite";
const description = "Explore Eventbrite's light Media design system: Canvas White #ffffff, Porcelain Mist #f8f7fa colors, Neue Plak, Neue Plak Text typography, and DESIGN.md for...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
