import './style.css';

const colors = ["#00ed64","#00b545","#f06bb8","#008c34","#001e2b","#00684a","#00a35c","#c3f0d2","#003d4f","#7b3ff2","#fa6e39","#3d4f9f"];
const title = "MongoDB";
const description = "Document database. Green leaf branding, developer documentation focus.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
