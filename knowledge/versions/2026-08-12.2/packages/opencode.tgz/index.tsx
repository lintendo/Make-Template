import './style.css';

const colors = ["#201d1d","#0f0000","#fdfcfc","#302c2c","#424245","#646262","#6e6e73","#9a9898","#f8f7f7","#f1eeee","#007aff","#0056b3"];
const title = "OpenCode";
const description = "AI coding platform. Developer-centric dark theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
