import './style.css';

const colors = ["#0066cc","#0071e3","#1d1d1f","#2997ff","#ffffff","#cccccc","#333333","#7a7a7a","#f0f0f0","#e0e0e0","#f5f5f7","#fafafc"];
const title = "Apple";
const description = "Consumer electronics. Premium white space, SF Pro, cinematic imagery.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
