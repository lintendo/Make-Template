import './style.css';

const colors = ["#ab5700","#e5dccd","#7997ff","#e8e359","#d99623","#568037","#3d549c","#103d26","#e99686","#214534","#5e335d","#c42331"];
const title = "arte*";
const description = "Explore arte*'s light E-commerce design system: Amber Ochre #ab5700, Pale Sage #e5dccd colors, Poppins, Parafina typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
