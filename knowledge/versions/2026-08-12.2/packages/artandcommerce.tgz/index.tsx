import './style.css';

const colors = ["#e7e7e7","#000000","#121212","#fafafa","#1c1c1c","#141109","#dcdcdc","#c2b5ae","#8c8c8c","#ecebe7","#ffffff","#f9f7f3"];
const title = "Artandcommerce";
const description = "Explore Artandcommerce's dark Media design system: Deep Night #000000, Ghost White #e7e7e7 colors, Adobe Garamond, Akzidenz Grotesk typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
