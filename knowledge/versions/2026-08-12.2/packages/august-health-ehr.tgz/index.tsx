import './style.css';

const colors = ["#080331","#1b1463","#000000","#ffffff","#cccccc","#f8f3eb","#328a3b","#4865ff","#0d5238","#ff6d39","#f098d7","#114e0b"];
const title = "August Health EHR";
const description = "Explore August Health EHR's light Other design system: Midnight Ink #080331, Regal Violet #1b1463 colors, Saans, Reckless Neue typography, and DESIGN.md for...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
