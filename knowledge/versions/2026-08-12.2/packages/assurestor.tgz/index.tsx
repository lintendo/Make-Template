import './style.css';

const colors = ["#203400","#bdff00","#ffffff","#1b2d00","#586740","#73a303","#335400","#041734","#002652","#0f172a","#374151","#1f2937"];
const title = "Assurestor";
const description = "Explore Assurestor's dark Fintech design system: Forest Canvas #203400, Lime Accent #bdff00 colors, Denim Ink, courier new typography, and DESIGN.md for AI...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
