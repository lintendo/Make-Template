import './style.css';

const colors = ["#7132f5","#a0a0a0","#000000","#fbbf24","#8a8a8a","#0a0a0a","#e0e0e0","#ffffff"];
const title = "Kraken";
const description = "Crypto trading. Purple-accented dark UI, data-dense dashboards.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
