import './style.css';

const colors = ["#23251d","#f7a501","#b17816","#dd9001","#4d4f46","#33342d","#6c6e63","#9b9c92","#b6b7af","#bfc1b7","#dcdfd2","#ffffff"];
const title = "PostHog";
const description = "Product analytics. Playful hedgehog branding, developer-friendly dark UI.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
