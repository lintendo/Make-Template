import './style.css';

const colors = ["#58cc02","#d7ffb8","#3c3c3c","#000000","#100f3e","#ffffff","#777777","#4b4b4b","#042c60","#e5e5e5","#1cb0f6","#a5ed6e"];
const title = "Duolingo";
const description = "Explore Duolingo's light Other design system: Duolingo Green #58cc02, Background Green Accent #d7ffb8 colors, din-round, feather typography, and DESIGN.md...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
