import './style.css';

const colors = ["#262626","#686868","#ffffff","#515151","#171717","#929292","#737373","#22c55e","#cbcbcb","#155dfc","#9810fa","#00a63e"];
const title = "Audyr";
const description = "Explore Audyr's light SaaS design system: Ink #262626, Canvas White #ffffff colors, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
