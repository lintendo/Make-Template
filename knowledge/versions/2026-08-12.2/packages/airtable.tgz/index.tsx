import './style.css';

const colors = ["#181d26","#0d1218","#333840","#41454d","#dddddd","#9297a0","#ffffff","#f8fafc","#e0e2e6","#1d1f25","#aa2d00","#0a2e0e"];
const title = "Airtable";
const description = "Spreadsheet-database hybrid. Colorful, friendly, structured data aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
