import './style.css';

const colors = ["#f9f9f7","#000000","#d2ddd2","#1c1c1c","#bed4fb","#edfe5e","#c7c7c6","#dee5dd","#edf0e9","#31e992","#10b5ff","#f7f0af"];
const title = "Switch-Lit";
const description = "Explore Switch-Lit's light Media design system: Midnight Ink #000000, Cloud Canvas #f9f9f7 colors, ABCArizonaSans, ABCArizonaSansVariable typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
