import './style.css';

const colors = ["#fcd535","#f0b90b","#181a20","#3a3a1f","#eaecef","#707a8a","#929aa5","#2b3139","#cdd1d6","#ffffff","#0b0e11","#1e2329"];
const title = "Binance";
const description = "Crypto exchange. Bold yellow accent on monochrome, trading-floor urgency.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
