import './style.css';

const colors = ["#3ecf8e","#24b47e","#171717","#4ade80","#212121","#707070","#9a9a9a","#b2b2b2","#ffffff","#fafafa","#1c1c1c","#202020"];
const title = "Supabase";
const description = "Open-source Firebase alternative. Dark emerald theme, code-first.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
