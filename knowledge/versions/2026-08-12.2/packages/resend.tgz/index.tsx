import './style.css';

const colors = ["#000000","#0a0a0c","#fcfdff","#06060a","#3b9eff","#a1a4a5","#888e90","#464a4d","#101012","#ff801f","#ffc53d","#11ff99"];
const title = "Resend";
const description = "Email API. Minimal dark theme, monospace accents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
