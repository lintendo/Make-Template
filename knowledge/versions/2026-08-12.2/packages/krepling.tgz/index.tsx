import './style.css';

const colors = ["#f1f1f1","#000000","#ffffff","#171717","#6c6b6b","#b3b3b3","#f9c2cf","#635bff","#ffe01b","#4b154c","#99e1f4","#93d33e"];
const title = "Krepling";
const description = "Explore Krepling's light E-commerce design system: White Canvas #ffffff, Midnight Text #000000 colors, Regular, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
