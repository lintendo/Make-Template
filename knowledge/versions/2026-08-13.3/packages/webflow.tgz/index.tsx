import './style.css';

const colors = ["#080808","#006acc","#222222","#ffffff","#363636","#5a5a5a","#898989","#ababab","#d8d8d8","#7a3dff","#ed52cb","#3b89ff"];
const title = "Webflow";
const description = "Visual web builder. Blue-accented, polished marketing site aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
