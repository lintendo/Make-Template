import './style.css';

const colors = ["#ffffff","#171717","#1a1a1a","#0d74ce","#000000","#476cff","#60646c","#999999","#cccccc","#f0f0f3","#f5f5f7","#dcdee0"];
const title = "Expo";
const description = "React Native platform. Dark theme, tight letter-spacing, code-centric.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
