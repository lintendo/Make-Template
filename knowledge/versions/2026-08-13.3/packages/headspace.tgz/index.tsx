import './style.css';

const colors = ["#0061ef","#ffce00","#3b197f","#00a4ff","#ffa1cc","#4b4c4d","#000000","#2d2c2b","#f9f4f2","#44423f","#ffffff","#e2ded9"];
const title = "Headspace";
const description = "Explore Headspace's light Other design system: Sky Connect #0061ef, Sunshine Burst #ffce00 colors, Headspace Apercu typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
