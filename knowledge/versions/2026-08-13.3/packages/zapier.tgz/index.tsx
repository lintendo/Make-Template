import './style.css';

const colors = ["#ff4f00","#201515","#fffefb","#2f2a26","#36342e","#605d52","#939084","#c5c0b1","#f8f4f0","#a0a0a0","#000000","#fbbf24"];
const title = "Zapier";
const description = "Automation platform. Warm orange, friendly illustration-driven.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
