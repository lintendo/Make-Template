import './style.css';

const colors = ["#171717","#000000","#090909","#ffffff","#525252","#737373","#a3a3a3","#fafafa","#e5e5e5","#d4d4d4","#ff5f56","#ffbd2e"];
const title = "Ollama";
const description = "Run LLMs locally. Terminal-first, monochrome simplicity.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
