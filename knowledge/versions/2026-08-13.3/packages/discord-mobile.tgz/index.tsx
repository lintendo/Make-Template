import './style.css';

const colors = ["#5865F2","#4752C4","#1E1F22","#2B2D31","#313338","#383A40","#3F4147","#F2F3F5","#B5BAC1","#949BA4","#00A8FC","#23A55A"];
const title = "Discord";
const description = "Discord mobile product theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
