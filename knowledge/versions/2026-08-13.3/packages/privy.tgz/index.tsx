import './style.css';

const colors = ["#111117","#000000","#ffffff","#22222a","#072723","#635bff","#010110","#73737c","#cbcde1","#808080","#333333","#6cedaf"];
const title = "Privy";
const description = "Explore Privy's light Fintech design system: Canvas White #ffffff, Ink Black #000000 colors, sans-serif, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
