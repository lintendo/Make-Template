import './style.css';

const colors = ["#fafaf9","#e5e7eb","#ffffff","#78716c","#afafae","#0c0a09","#a8a29e","#c9c5c2","#d6d3d1","#c1e1f7","#3ba6f1","#928d89"];
const title = "Seline Analytics";
const description = "Explore Seline Analytics's light SaaS design system: Cloud White #ffffff, Canvas Fog #fafaf9 colors, Inter, roobert typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
