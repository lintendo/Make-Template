import './style.css';

const colors = ["#150f23","#1f1633","#ffffff","#c2ef4e","#fa7faa","#6a5fc1","#422082","#79628c","#f0f0f0","#efefef","#362d59","#cfcfdb"];
const title = "Sentry";
const description = "Error monitoring. Dark dashboard, data-dense, pink-purple accent.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
