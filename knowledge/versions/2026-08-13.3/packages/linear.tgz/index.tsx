import './style.css';

const colors = ["#010102","#5e6ad2","#5e69d1","#f7f8f8","#ffffff","#828fff","#d0d6e0","#8a8f98","#62666d","#0f1011","#141516","#18191a"];
const title = "Linear";
const description = "Project management. Ultra-minimal, precise, purple accent.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
