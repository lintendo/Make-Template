import './style.css';

const colors = ["#1a73e8","#188038","#1967d2","#f8f9fa","#202124","#3c4043","#5f6368","#dadce0","#ffffff","#e8f0fe","#e6f4ea","#fef9e7"];
const title = "Google for Education";
const description = "Explore Google for Education's light Other design system: Classroom Blue #1a73e8, Educator Green #188038 colors, Google Sans Display, Google Sans Text...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
