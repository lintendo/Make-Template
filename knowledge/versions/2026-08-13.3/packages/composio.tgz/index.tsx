import './style.css';

const colors = ["#0f0f0f","#181818","#0007cd","#0005a3","#ffffff","#1a26ff","#a8a8a8","#888888","#666666","#222222","#1a1a1a","#333333"];
const title = "Composio";
const description = "Tool integration platform. Modern dark with colorful integration icons.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
