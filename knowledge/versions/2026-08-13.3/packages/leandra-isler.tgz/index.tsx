import './style.css';

const colors = ["#f4e6cd","#edddc3","#1e211e","#888151","#000000","#b59866","#a29a65","#8ed59a","#8f774b","#ffffff","#f7f5ee","#ece9df"];
const title = "Leandra-isler";
const description = "Explore Leandra-isler's light Other design system: Amber Canvas #f4e6cd, Pale Ochre #edddc3 colors, PP Neue Montreal typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
