import './style.css';

const colors = ["#0a0a0a","#00b48a","#a8a8aa","#ffffff","#00d4a4","#7cebcb","#3772cf","#c37d0d","#1ba673","#d45656","#888888","#87a8c8"];
const title = "Mintlify";
const description = "Documentation platform. Clean, green-accented, reading-optimized.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
