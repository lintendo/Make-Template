import './style.css';

const colors = ["#1c1c1e","#fcb900","#fde0f0","#ffffff","#ffd02f","#fff4c4","#746019","#4262ff","#5b76fe","#2a41b6","#ff9999","#ffc6c6"];
const title = "Miro";
const description = "Visual collaboration. Bright yellow accent, infinite canvas aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
