import './style.css';

const colors = ["#0a0a0a","#121212","#faff69","#e6eb52","#ffffff","#3a3a1f","#cccccc","#e6e6e6","#888888","#5a5a5a","#2a2a2a","#3a3a3a"];
const title = "ClickHouse";
const description = "Fast analytics database. Yellow-accented, technical documentation style.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
