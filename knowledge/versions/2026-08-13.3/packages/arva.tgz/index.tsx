import './style.css';

const colors = ["#07503f","#b2cee7","#212529","#ffffff","#f1efdf","#353535","#efefef","#fceace","#e6ecd5","#e8fe85","#c3cda7","#e4e4e4"];
const title = "Arva";
const description = "Explore Arva's light Other design system: Arva Forest #07503f, Garden Dew #b2cee7 colors, Inter, RecklessLight typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
