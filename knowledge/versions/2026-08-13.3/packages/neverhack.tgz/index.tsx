import './style.css';

const colors = ["#0A0F1F","#E5E7EB","#FFFFFF","#6B2BEA","#dc2626","#f6f7fc","#d8d7e2","#4e4e4e","#c9c7d7","#777169","#000000","#999999"];
const title = "NEVERHACK";
const description = "Explore NEVERHACK's light Other design system: Midnight Ink #0A0F1F, Ghost White #FFFFFF colors, Roobert typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
