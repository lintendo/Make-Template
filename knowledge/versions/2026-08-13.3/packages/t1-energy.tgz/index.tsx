import './style.css';

const colors = ["#0f0e12","#322d2a","#ffffff","#f0efe9","#000000","#8b8b8b","#202020","#afafaf","#eeeeee","#fff313","#4b4b4b","#fafafa"];
const title = "T1 Energy";
const description = "Explore T1 Energy's light Other design system: Nightfall Onyx #0f0e12, Platinum White #ffffff colors, T1 Sans typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
