# Source and License

This sanitized theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/e79b761d-f476-4c5d-8943-e31a58664e4d

Excluded from this install package: screenshots, promotional images, logos, proprietary icons, and font binaries.
