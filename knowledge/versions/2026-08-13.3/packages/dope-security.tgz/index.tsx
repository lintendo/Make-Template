import './style.css';

const colors = ["#090909","#f7f9fa","#f0f0f0","#6b6b6b","#454545","#828384","#af50ff","#423738","#333333","#475467","#271635","#7f56d9"];
const title = "dope.security";
const description = "Explore dope.security's dark SaaS design system: Midnight Eclipse #090909, Cloud Whisper #f7f9fa colors, Whyte Inktrap, Whyte Inktrap Mono typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
