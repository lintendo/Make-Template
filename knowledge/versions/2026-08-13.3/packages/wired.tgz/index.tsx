import './style.css';

const colors = ["#000000","#057dbc","#1a1a1a","#ffffff","#757575","#e0e0e0","#f5f5f5","#a0a0a0","#fbbf24","#8a8a8a","#0a0a0a"];
const title = "Wired";
const description = "Tech magazine. Paper-white broadsheet density, custom serif display, mono kickers, ink-blue links.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
