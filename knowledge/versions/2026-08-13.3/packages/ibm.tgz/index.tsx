import './style.css';

const colors = ["#0f62fe","#161616","#ffffff","#525252","#8c8c8c","#f4f4f4","#e0e0e0","#262626","#c6c6c6","#0043ce","#002d9c","#0050e6"];
const title = "IBM";
const description = "Enterprise technology. Carbon design system, structured blue palette.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
