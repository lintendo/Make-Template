import './style.css';

const colors = ["#101010","#00d992","#10b981","#f2f2f2","#2fd6a1","#ffffff","#bdbdbd","#8b949e","#3d3a39","#b8b3b0","#1a1a1a","#f5f6f7"];
const title = "VoltAgent";
const description = "AI agent framework. Void-black canvas, emerald accent, terminal-native.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
