import './style.css';

const colors = ["#0a0b0d","#0052ff","#003ecc","#a8b8cc","#5b616e","#7c828a","#a8acb3","#dee1e6","#eef0f3","#ffffff","#f7f7f7","#16181c"];
const title = "Coinbase";
const description = "Crypto exchange. Clean blue identity, trust-focused, institutional feel.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
