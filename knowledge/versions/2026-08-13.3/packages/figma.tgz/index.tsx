import './style.css';

const colors = ["#000000","#e6e6e6","#ffffff","#f1f1f1","#f7f7f5","#dceeb1","#c5b0f4","#f4ecd6","#efd4d4","#c8e6cd","#f3c9b6","#1f1d3d"];
const title = "Figma";
const description = "Collaborative design tool. Vibrant multi-color, playful yet professional.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
