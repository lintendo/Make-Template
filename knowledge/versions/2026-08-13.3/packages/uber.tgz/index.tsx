import './style.css';

const colors = ["#000000","#0000ee","#5e5e5e","#ffffff","#afafaf","#4b4b4b","#efefef","#f3f3f3","#e2e2e2","#282828","#a0a0a0","#fbbf24"];
const title = "Uber";
const description = "Mobility platform. Bold black and white, tight type, urban energy.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
