import './style.css';

const colors = ["#16191c","#1e2327","#000000","#f9f9f9","#dadadd","#5b6065","#1ebfbf","#ffffff","#bfbfc0","#393e41","#ffc200","#fa3556"];
const title = "Surfshark";
const description = "Explore Surfshark's mixed Other design system: Midnight Ink #16191c, Stormy Night #1e2327 colors, Inter typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
