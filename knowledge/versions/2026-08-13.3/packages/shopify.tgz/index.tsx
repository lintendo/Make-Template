import './style.css';

const colors = ["#000000","#9dabad","#ffffff","#0a0a0a","#fbfbf5","#1e2c31","#d4d4d8","#a1a1aa","#71717a","#52525b","#3f3f46","#e4e4e7"];
const title = "Shopify";
const description = "E-commerce platform. Dark-first cinematic, neon green accent, ultra-light type.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
