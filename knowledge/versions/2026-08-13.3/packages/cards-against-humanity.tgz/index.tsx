import './style.css';

const colors = ["#fe2f2f","#000000","#ffffff","#fffe5b","#7333f1","#d7b73b","#ede5ff","#1b5bff","#a0e9ff","#ffa0f0","#b4ff91","#ff9559"];
const title = "Cards Against Humanity";
const description = "Explore Cards Against Humanity's dark Other design system: Midnight Ink #000000, Canvas White #ffffff colors, Helvetica Neue LT, Helvetica Neue typography,...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
