import './style.css';

const colors = ["#181715","#cc785c","#a9583e","#141413","#e6dfd8","#3d3d3a","#252523","#6c6a64","#8e8b82","#ebe6df","#faf9f5","#f5f0e8"];
const title = "Claude";
const description = "Anthropic's AI assistant. Warm terracotta accent, clean editorial layout.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
