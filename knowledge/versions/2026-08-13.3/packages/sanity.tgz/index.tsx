import './style.css';

const colors = ["#0b0b0b","#dd0000","#212121","#ffffff","#f36458","#353535","#3c4758","#505b6c","#797979","#b9b9b9","#ededed","#0052ef"];
const title = "Sanity";
const description = "Headless CMS. Red accent, content-first editorial layout.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
