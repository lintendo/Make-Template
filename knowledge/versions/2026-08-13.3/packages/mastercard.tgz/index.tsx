import './style.css';

const colors = ["#EB001B","#000000","#ffffff","#a0a0a0","#fbbf24","#8a8a8a","#0a0a0a","#e0e0e0"];
const title = "Mastercard";
const description = "Global payments network. Warm cream canvas, orbital pill shapes, editorial warmth.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
