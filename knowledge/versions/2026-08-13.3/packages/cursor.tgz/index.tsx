import './style.css';

const colors = ["#f7f7f4","#26251e","#ffffff","#d04200","#f54e00","#5a5852","#807d72","#a09c92","#e6e5e0","#efeee8","#cfcdc4","#fafaf7"];
const title = "Cursor";
const description = "AI-first code editor. Sleek dark interface, gradient accents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
