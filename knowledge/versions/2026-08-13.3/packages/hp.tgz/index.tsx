import './style.css';

const colors = ["#024ad8","#0e3191","#1a1a1a","#296ef9","#c9e0fc","#ffffff","#000000","#292929","#f7f7f7","#e8e8e8","#c2c2c2","#636363"];
const title = "HP";
const description = "Consumer electronics catalog. White canvas with electric blue accent, angular chevron motifs.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
