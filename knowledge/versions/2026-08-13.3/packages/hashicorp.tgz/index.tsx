import './style.css';

const colors = ["#000000","#12b6bb","#ffffff","#2b89ff","#b2b6bd","#656a76","#15181e","#1f232b","#3b3d45","#252830","#7b42bc","#911ced"];
const title = "HashiCorp";
const description = "Infrastructure automation. Enterprise-clean, black and white.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
