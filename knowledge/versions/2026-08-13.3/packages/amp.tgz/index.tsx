import './style.css';

const colors = ["#ff6105","#ffdfcd","#e5e5e5","#0a0a0a","#ffffff","#f3f4f3","#3c3e3d","#a89a8b","#cccccc","#292b2a","#e5e7eb","#fff8e9"];
const title = "amp";
const description = "Explore amp's light Other design system: Orange Ember #ff6105, Soft Peach #ffdfcd colors, PublicaSans typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
