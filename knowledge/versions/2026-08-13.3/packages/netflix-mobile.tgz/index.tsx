import './style.css';

const colors = ["#E50914","#B7070F","#141414","#000000","#1F1F1F","#2A2A2A","#3A3A3A","#2B2B2B","#333333","#FFFFFF","#AAAAAA","#777777"];
const title = "Netflix";
const description = "Netflix mobile product theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
