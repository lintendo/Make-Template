# Source and License

This pinned theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/9905b62f-007b-4b3a-9357-84e85c07ef96

Visual references are included from the pinned source tree by verified path and SHA-256 for design reference.
Third-party names and visual materials do not imply endorsement of Axhub. Font binaries remain excluded.
