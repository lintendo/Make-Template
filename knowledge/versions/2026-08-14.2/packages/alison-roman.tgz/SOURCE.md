# Source and License

This pinned theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/b2ace2c1-d6ee-4d57-915e-901224cded11

Visual references are included from the pinned source tree by verified path and SHA-256 for design reference.
Third-party names and visual materials do not imply endorsement of Axhub. Font binaries remain excluded.
