import React from 'react';
import './style.css';

const colors = ["#262622","#e60023","#000000","#ffffff","#cc001f","#211922","#33332e","#62625b","#91918c","#c8c8c1","#dadad3","#e5e5e0"];
const title = "Pinterest";
const description = "Visual discovery. Red accent, masonry grid, image-first.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
