import React from 'react';
import './style.css';

const colors = ["#000000","#1a1a1a","#ffffff","#bbbbbb","#e6e6e6","#7e7e7e","#3c3c3c","#262626","#0d0d0d","#0066b1","#1c69d4","#e22718"];
const title = "BMW M";
const description = "Motorsport automotive. Pure black canvas, M tricolor stripe accents, full-bleed photography.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
