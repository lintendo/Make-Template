import React from 'react';
import './style.css';

const colors = ["#fff7dd","#000000","#c8ad86","#66635f","#080808","#171617","#262525","#393939","#fcfcfc","#de4c00","#efa680","#040c06"];
const title = "Atoms";
const description = "Explore Atoms's dark Other design system: Absolute Zero #000000, Alabaster #fff7dd colors, Switzer, sans-serif typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
