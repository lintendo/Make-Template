import React from 'react';
import './style.css';

const colors = ["#101010","#111111","#242424","#374151","#e5e7eb","#6b7280","#898989","#f3f4f6","#ffffff","#f8f9fa","#f5f5f5","#1a1a1a"];
const title = "Cal.com";
const description = "Open-source scheduling. Clean neutral UI, developer-oriented simplicity.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
