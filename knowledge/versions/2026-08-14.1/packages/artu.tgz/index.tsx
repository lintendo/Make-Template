import React from 'react';
import './style.css';

const colors = ["#d7ff66","#000000","#ffffff","#ff1313","#f6f6f6","#2e2e20","#c9c9c9","#321929","#e0dddf","#808080","#1d1d1f","#24241f"];
const title = "ARTU";
const description = "Explore ARTU's light E-commerce design system: Canvas White #ffffff, Obsidian Ink #000000 colors, Helvetica Neue Pro typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
