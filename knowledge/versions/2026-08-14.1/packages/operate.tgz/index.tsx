import React from 'react';
import './style.css';

const colors = ["#e0e0e0","#29211e","#433787","#85c093","#09352e","#222222","#007010","#117025","#ffffff","#000000","#453b41","#e5e5e5"];
const title = "Operate";
const description = "Explore Operate's light SaaS design system: Canvas Fog #e0e0e0, Inkwell #29211e colors, muoto, denim typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
