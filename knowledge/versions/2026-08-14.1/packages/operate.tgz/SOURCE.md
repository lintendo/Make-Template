# Source and License

This sanitized theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/f682f0ea-632d-4d09-bfdf-6a43f5e5a7d8

Excluded from this install package: screenshots, promotional images, logos, proprietary icons, and font binaries.
