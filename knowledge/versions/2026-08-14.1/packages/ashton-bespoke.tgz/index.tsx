import React from 'react';
import './style.css';

const colors = ["#e0ded8","#262626","#38141b","#ffffff","#000000","#f6f6f6","#2e2e20","#c9c9c9","#060daa","#191817","#fcfaee","#555555"];
const title = "Ashton Bespoke";
const description = "Explore Ashton Bespoke's light Design design system: Stone Canvas #e0ded8, Midnight Ink #262626 colors, Arial, Legquinne Vf typography, and DESIGN.md for AI...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
