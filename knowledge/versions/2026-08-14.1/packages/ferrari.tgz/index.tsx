import React from 'react';
import './style.css';

const colors = ["#181818","#303030","#da291c","#b01e0a","#ffffff","#9d2211","#969696","#666666","#8f8f8f","#d2d2d2","#ebebeb","#f7f7f7"];
const title = "Ferrari";
const description = "Luxury automotive. Chiaroscuro editorial, Ferrari Red accents, cinematic black.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
