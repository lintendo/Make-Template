import React from 'react';
import './style.css';

const colors = ["#f4f4f5","#52525b","#18181b","#ffffff","#e5e7eb","#10b981","#059669","#a1a1aa","#71717a","#a7f3d0","#a5b4fc","#e9d5ff"];
const title = "Podscan.fm";
const description = "Explore Podscan.fm's light Media design system: Absolute Zero #f4f4f5, Graphite #52525b colors, Inter Tight, ui-sans-serif typography, and DESIGN.md for AI...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
