import React from 'react';
import './style.css';

const colors = ["#17171c","#003c33","#212121","#000000","#071829","#ffffff","#eeece7","#edfce9","#f1f5ff","#d9d9dd","#e5e7eb","#f2f2f2"];
const title = "Cohere";
const description = "Enterprise AI platform. Vibrant gradients, data-rich dashboard aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
