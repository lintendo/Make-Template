import React from 'react';
import './style.css';

const colors = ["#2b2622","#f7f5f0","#c9c0ad","#dad2c1","#aea69c","#383330","#3f3a36","#a0a0a0","#000000","#fbbf24","#8a8a8a","#0a0a0a"];
const title = "Warp";
const description = "Modern terminal. Dark IDE-like interface, block-based command UI.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
