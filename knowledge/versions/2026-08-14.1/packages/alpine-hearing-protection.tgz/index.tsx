import React from 'react';
import './style.css';

const colors = ["#200e0e","#ed212d","#ffffff","#f3e7e2","#f8f0ec","#d2cfcf","#fde3d6","#000000","#d9d9d9","#202020","#9ac9b5","#dbb0b3"];
const title = "Alpine Hearing Protection";
const description = "Explore Alpine Hearing Protection's light E-commerce design system: Inkwell #200e0e, Crimson Accent #ed212d colors, Antarctica, GTStandard-M typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
