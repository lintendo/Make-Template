import React from 'react';
import './style.css';

const colors = ["#202020","#000000","#afafaf","#eeeeee","#fff313","#4b4b4b","#2a2a2a","#1a1a1a","#d4a614","#b8860b","#3a3020","#3a4a5a"];
const title = "ON.energy";
const description = "Explore ON.energy's dark AI design system: Midnight Steel #000000, Data Center Graphite #202020 colors, Univers Next Pro typography, and DESIGN.md for AI...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
