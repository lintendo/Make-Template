import React from 'react';
import './style.css';

const colors = ["#0070d1","#004d8d","#0064b7","#ffffff","#53b1ff","#d53b00","#aa2f00","#d63d00","#000000","#121314","#181818","#1f2024"];
const title = "Playstation";
const description = "Gaming console retail. Three-surface channel layout, quiet-authority display type, cyan hover-scale.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
