import React from 'react';
import './style.css';

const colors = ["#000000","#ff385c","#e00b41","#c13515","#ffd1da","#b32505","#460479","#92174d","#222222","#3f3f3f","#6a6a6a","#929292"];
const title = "Airbnb";
const description = "Travel marketplace. Warm coral accent, photography-driven, rounded UI.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
