import React from 'react';
import './style.css';

const colors = ["#303030","#F2F2F2","#FFFFFF","#DBDBDB","#808080","#C2C2C2","#F9F5A2","#648FE0","#0064E2","#b0c4d8","#8ab4d4","#6a9cbf"];
const title = "School";
const description = "Explore School's light Other design system: Ink #303030, Paper White #FFFFFF colors, IBM Plex Mono, Helvetica typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
