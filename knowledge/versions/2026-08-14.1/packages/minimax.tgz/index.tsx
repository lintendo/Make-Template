import React from 'react';
import './style.css';

const colors = ["#0a0a0a","#1d4ed8","#000000","#ffffff","#181e25","#ff5530","#ea5ec1","#1456f0","#3b82f6","#17437d","#3daeff","#bfdbfe"];
const title = "Minimax";
const description = "AI model provider. Bold dark interface with neon accents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
