import React from 'react';
import './style.css';

const colors = ["#1d1d1d","#000000","#ffffff","#d6d5d0","#fafafa","#1c1c1c","#141109","#dcdcdc","#c2b5ae","#4d4d4d","#161a1c","#ebf3f6"];
const title = "Athletics";
const description = "Explore Athletics's dark Agency design system: Midnight Gown #000000, Canvas White #ffffff colors, Feature Deck, Söhne typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
