import React from 'react';
import './style.css';

const colors = ["#0a0a0a","#ffffff","#fafaf7","#dadbdf","#7d8187","#212327","#1a1c20","#191919","#363a3f","#ff7a17","#ffc285","#7c3aed"];
const title = "xAI";
const description = "Elon Musk's AI lab. Stark monochrome, futuristic minimalism.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
