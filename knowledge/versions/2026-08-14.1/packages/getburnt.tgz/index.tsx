import React from 'react';
import './style.css';

const colors = ["#1a1a17","#5f5f5d","#ffffff","#d71920","#de4c00","#efa680","#040c06","#271503","#eadfcf","#a49784","#f5f5f5","#000000"];
const title = "Getburnt";
const description = "Explore Getburnt's light AI design system: Storm Charcoal #1a1a17, Canvas White #ffffff colors, Nyght Serif, Switzer typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
