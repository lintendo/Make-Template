import React from 'react';
import './style.css';

const colors = ["#f8f5ed","#000000","#FFFFFF","#707070","#ffda6e","#6ece9d","#181925","#666666","#999999","#e8e8e8","#dad9fc","#fafaf9"];
const title = "Pirsch Analytics";
const description = "Explore Pirsch Analytics's light SaaS design system: Midnight Ink #000000, Ghostly Gray #f8f5ed colors, DM Sans typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
