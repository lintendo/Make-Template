# Source and License

This sanitized theme source package is distributed under the MIT License.

Copyright (c) 2026 lintendo

Repository: https://github.com/lintendo/Axhub-Runtime
Source commit: 0fa70b810ff51d98fe1c142243c45ed008cd7ab0
License evidence: https://github.com/lintendo/Axhub-Runtime/blob/0fa70b810ff51d98fe1c142243c45ed008cd7ab0/LICENSE
Original source: https://styles.refero.design/style/afde66c4-ad74-4d19-94df-0216e945ac5e

Excluded from this install package: screenshots, promotional images, logos, proprietary icons, and font binaries.
