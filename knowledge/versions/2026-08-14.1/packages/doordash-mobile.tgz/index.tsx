import React from 'react';
import './style.css';

const colors = ["#EB1700","#C31500","#FFEBE8","#FFFFFF","#191919","#757575","#F7F7F7","#E5E5E5","#FF8000","#008B4A","#006B82"];
const title = "Doordash";
const description = "Doordash mobile product theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
