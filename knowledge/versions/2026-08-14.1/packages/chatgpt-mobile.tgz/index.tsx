import React from 'react';
import './style.css';

const colors = ["#0D0D0D","#FFFFFF","#212121","#ECECEC","#F7F7F8","#2F2F2F","#E5E5E5","#676767","#8E8E8E","#2A7FFF","#CCCCCC","#4D4D4D"];
const title = "Chatgpt";
const description = "Chatgpt mobile product theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
