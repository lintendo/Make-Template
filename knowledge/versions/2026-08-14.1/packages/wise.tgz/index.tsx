import React from 'react';
import './style.css';

const colors = ["#9fe870","#cdffad","#0e0f0c","#c5edab","#e2f6d5","#163300","#454745","#868685","#ffffff","#e8ebe6","#2ead4b","#054d28"];
const title = "Wise";
const description = "Money transfer. Bright green accent, friendly and clear.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
