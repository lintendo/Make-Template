import React from 'react';
import './style.css';

const colors = ["#f6f0e1","#290a08","#e5e7eb","#810c00","#ffffff","#fff3cc","#fffaec","#143930","#f8f2de","#456859","#f8f5f5","#cfc6c7"];
const title = "Alison Roman";
const description = "Explore Alison Roman's light Media design system: Parchment Cream #f6f0e1, Ink Black #290a08 colors, Jannon Neo, Modale Antique typography, and DESIGN.md...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
