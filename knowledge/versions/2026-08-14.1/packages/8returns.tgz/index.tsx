import React from 'react';
import './style.css';

const colors = ["#051923","#004853","#ffffff","#000000","#eef0f2","#1e3039","#bfbfbf","#c8d4e0","#cfff69","#6289ff","#525252","#e0e0e0"];
const title = "8returns";
const description = "Explore 8returns's light E-commerce design system: Midnight Ink #051923, Lagoon Teal #004853 colors, roobert typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
