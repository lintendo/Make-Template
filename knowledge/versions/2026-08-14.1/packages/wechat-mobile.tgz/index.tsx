import React from 'react';
import './style.css';

const colors = ["#07C160","#06A050","#95EC69","#EDEDED","#FFFFFF","#F7F7F7","#D9D9D9","#181818","#888888","#B2B2B2","#FA5151","#576B95"];
const title = "Wechat";
const description = "Wechat mobile product theme.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
