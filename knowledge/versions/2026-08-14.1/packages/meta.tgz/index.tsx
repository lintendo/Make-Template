import React from 'react';
import './style.css';

const colors = ["#0064e0","#0457cb","#000000","#0091ff","#ffffff","#1876f2","#385898","#a121ce","#31a24c","#24e400","#f2a918","#f7b928"];
const title = "Meta";
const description = "Tech retail store. Photography-first, binary light/dark surfaces, Meta Blue CTAs.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
