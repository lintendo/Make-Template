import React from 'react';
import './style.css';

const colors = ["#000000","#0d0d0d","#ffffff","#c3d9f3","#cccccc","#e6e6e6","#999999","#666666","#262626","#3a3a3a","#141414","#1f1f1f"];
const title = "Bugatti";
const description = "Hypercar brand. Cinema-black canvas, monochrome austerity, monumental display type.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
