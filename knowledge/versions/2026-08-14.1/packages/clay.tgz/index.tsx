import React from 'react';
import './style.css';

const colors = ["#0a1a1a","#0a0a0a","#1f1f1f","#3a3a3a","#e5e5e5","#1a1a1a","#6a6a6a","#9a9a9a","#f0f0f0","#fffaf0","#faf5e8","#f5f0e0"];
const title = "Clay";
const description = "Creative agency. Organic shapes, soft gradients, art-directed layout.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
