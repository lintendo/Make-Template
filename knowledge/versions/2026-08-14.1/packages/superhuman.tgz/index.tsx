import React from 'react';
import './style.css';

const colors = ["#1b1938","#0e0c1f","#292827","#ffffff","#73706d","#9a9794","#fafaf8","#c9b4fa","#0e3030","#155555","#e8e4dd","#3f3a52"];
const title = "Superhuman";
const description = "Fast email client. Premium dark UI, keyboard-first, purple glow.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
