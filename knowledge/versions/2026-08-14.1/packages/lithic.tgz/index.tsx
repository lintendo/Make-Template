import React from 'react';
import './style.css';

const colors = ["#e5e5e5","#000000","#ffffff","#5c2999","#ff6600","#f6f3ee","#aa8855","#00cc88","#665233","#ebfef6","#f6f1fe","#808080"];
const title = "Lithic";
const description = "Explore Lithic's light Fintech design system: Obsidian #000000, Canvas White #ffffff colors, ABC Monument Grotesk, ABC Monument Grotesk typography, and...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
