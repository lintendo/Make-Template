import React from 'react';
import './style.css';

const colors = ["#171717","#0070f3","#4d4d4d","#ffffff","#888888","#ebebeb","#a1a1a1","#fafafa","#f5f5f5","#0761d1","#d3e5ff","#ee0000"];
const title = "Vercel";
const description = "Frontend deployment. Black and white precision, Geist font.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
