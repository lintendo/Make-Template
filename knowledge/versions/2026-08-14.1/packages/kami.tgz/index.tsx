import React from 'react';
import './style.css';

const colors = ["#f7f1e3","#1f3a5f","#2f2a24","#b88746","#fffaf0","#e4d5bd","#375f8e"];
const title = "Kami";
const description = "A document-first PC/Web theme for one-pagers, white papers, resumes, and portfolios.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
