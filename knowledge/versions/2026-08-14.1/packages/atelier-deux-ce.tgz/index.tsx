import React from 'react';
import './style.css';

const colors = ["#d8ddc6","#000000","#ffffff","#9c978a","#aaaaa4","#259558","#d8d0c5","#afb371","#683e28","#8b8c7d","#eee5da","#b2a895"];
const title = "Atelier Deux-Cé";
const description = "Explore Atelier Deux-Cé's light Agency design system: Midnight #000000, Canvas #ffffff colors, Helvetica, minion-3 typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
