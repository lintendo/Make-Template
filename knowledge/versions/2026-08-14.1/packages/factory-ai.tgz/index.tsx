import React from 'react';
import './style.css';

const colors = ["#020202","#eeeeee","#fafafa","#b8b3b0","#3d3a39","#a49d9a","#ef6f2e","#1f1d1c","#5c5855","#8a8380","#101010","#2e2c2b"];
const title = "Factory.ai";
const description = "Explore Factory.ai's light AI design system: Factory Black #020202, Factory Light Gray #eeeeee colors, Geist, Geist Mono typography, and DESIGN.md for AI...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
