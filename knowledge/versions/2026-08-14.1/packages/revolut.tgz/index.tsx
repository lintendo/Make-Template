import React from 'react';
import './style.css';

const colors = ["#0a0a0a","#494fdf","#3a40c4","#191c1f","#4f55f1","#ffffff","#1f2226","#3a3d40","#505a63","#5c5e60","#8d969e","#c9c9cd"];
const title = "Revolut";
const description = "Digital banking. Sleek dark interface, gradient cards, fintech precision.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
