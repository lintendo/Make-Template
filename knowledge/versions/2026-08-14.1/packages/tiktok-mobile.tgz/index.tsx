import React from 'react';
import './style.css';

const colors = ["#010101","#FE2C55","#25F4EE","#FFFFFF","#161823","#2F2F2F","#E5E5E5"];
const title = "TikTok";
const description = "TikTok dark mobile theme with full-bleed video, rose actions, and chromatic accents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
