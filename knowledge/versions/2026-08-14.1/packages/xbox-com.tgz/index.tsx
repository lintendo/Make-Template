import React from 'react';
import './style.css';

const colors = ["#107c10","#054b16","#9bf00b","#ffd800","#000000","#ffffff","#333333","#f2f2f2","#616161","#262626","#e0e0e0","#1a3a1a"];
const title = "Xbox.com";
const description = "Explore Xbox.com's light Media design system: Lumi Green #107c10, Rich Meadow #054b16 colors, Segoe UI, SegoeProBlack typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
