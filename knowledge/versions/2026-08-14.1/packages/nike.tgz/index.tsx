import React from 'react';
import './style.css';

const colors = ["#111111","#780700","#ed1aa0","#ffffff","#f5f5f5","#39393b","#4b4b4d","#707072","#9e9ea0","#cacacb","#e5e5e5","#d30005"];
const title = "Nike";
const description = "Athletic retail. Monochrome UI, massive uppercase type, full-bleed photography.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
