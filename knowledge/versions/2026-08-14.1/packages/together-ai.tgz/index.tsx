import React from 'react';
import './style.css';

const colors = ["#000000","#959494","#ffffff","#010120","#313641","#fc4c02","#ef2cc1","#bdbbff","#c8f6f9","#a0a0a0","#fbbf24","#8a8a8a"];
const title = "Together AI";
const description = "Open-source AI infrastructure. Technical, blueprint-style design.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
