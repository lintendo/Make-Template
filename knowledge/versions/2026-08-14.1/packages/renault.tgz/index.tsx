import React from 'react';
import './style.css';

const colors = ["#000000","#ffed00","#e6d200","#222222","#333333","#666666","#8a8a8a","#c4c4c4","#ffffff","#f7f7f7","#111111","#f2f2f2"];
const title = "Renault";
const description = "French automotive. Vibrant aurora gradients, NouvelR typography, bold energy.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
