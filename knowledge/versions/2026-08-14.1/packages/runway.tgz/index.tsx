import React from 'react';
import './style.css';

const colors = ["#1a1a1a","#000000","#030303","#ffffff","#404040","#676f7b","#727a85","#6b7280","#939393","#999999","#e7eaf0","#c9ccd1"];
const title = "Runway";
const description = "AI video generation. Cinematic dark UI, media-rich layout.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
