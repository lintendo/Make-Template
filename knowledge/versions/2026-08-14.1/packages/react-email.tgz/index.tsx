import React from 'react';
import './style.css';

const colors = ["#0f0f10","#000000","#ffffff","#27272a","#e5e7eb","#52e1fe","#abafb4","#ffb86a","#6e727a","#cccccc","#cad5e2","#1c1c1c"];
const title = "React Email";
const description = "Explore React Email's dark Dev Tools design system: Carbon #000000, Inkwell #0f0f10 colors, Inter, CommitMono typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
