import React from 'react';
import './style.css';

const colors = ["#0f3e17","#fffefc","#e5e7eb","#000000","#b1dbb8","#b6ced5","#e1f4df","#cfe7d3","#333333","#222222","#addbe8","#a9e6b0"];
const title = "Ease Health";
const description = "Explore Ease Health's light Other design system: Forest Green #0f3e17, Cream Canvas #fffefc colors, Suisseintl, Faire Octave typography, and DESIGN.md for...";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
