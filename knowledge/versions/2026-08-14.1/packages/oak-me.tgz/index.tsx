import React from 'react';
import './style.css';

const colors = ["#f6f1eb","#403a34","#333333","#00aa00","#555555","#e9e6ed","#ffffff","#321929","#e0dddf","#000000","#808080","#1d1d1f"];
const title = "Oakâme";
const description = "Explore Oakâme's light E-commerce design system: Earth Parchment #f6f1eb, Deep Charcoal #403a34 colors, BwGradual typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
