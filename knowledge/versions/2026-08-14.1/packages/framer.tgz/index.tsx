import React from 'react';
import './style.css';

const colors = ["#090909","#ffffff","#000000","#999999","#0099ff","#141414","#1c1c1c","#262626","#1a1a1a","#d44df0","#6a4cf5","#ff7a3d"];
const title = "Framer";
const description = "Website builder. Bold black and blue, motion-first, design-forward.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
