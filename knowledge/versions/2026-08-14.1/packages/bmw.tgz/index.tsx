import React from 'react';
import './style.css';

const colors = ["#1a2129","#1c69d4","#0653b6","#262626","#d6d6d6","#3c3c3c","#1a1a1a","#6b6b6b","#9a9a9a","#e6e6e6","#cccccc","#ffffff"];
const title = "BMW";
const description = "Luxury automotive. Dark premium surfaces, precise German engineering aesthetic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
