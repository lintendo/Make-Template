import React from 'react';
import './style.css';

const colors = ["#0d0d0f","#000000","#d8eaff","#1f58f2","#2b2f33","#232529","#565657","#6c757f","#ff4105","#565e66","#41464c","#efece6"];
const title = "Atlantic.vc";
const description = "Explore Atlantic.vc's dark Fintech design system: Deep Midnight #000000, Charcoal Canvas #0d0d0f colors, Monument, Mono typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
