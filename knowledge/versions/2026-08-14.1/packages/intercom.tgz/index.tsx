import React from 'react';
import './style.css';

const colors = ["#111111","#626260","#ffffff","#7b7b78","#9c9fa5","#f5f1ec","#ebe7e1","#000000","#313130","#d3cec6","#ff5600","#fe4c02"];
const title = "Intercom";
const description = "Customer messaging. Friendly blue palette, conversational UI patterns.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
