import React from 'react';
import './style.css';

const colors = ["#fdfcfc","#f5f3f1","#e5e5e5","#b1b0b0","#777169","#000000","#ffffff","#a59f97","#0447ff","#ff4704","#3a1c71","#d76d77"];
const title = "ElevenLabs";
const description = "Explore ElevenLabs's light AI design system: Eggshell #fdfcfc, Powder #f5f3f1 colors, Waldenburg, WaldenburgFH typography, and DESIGN.md for AI agents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
