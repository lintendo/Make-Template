import React from 'react';
import './style.css';

const colors = ["#5645d4","#3a2a99","#0075de","#4534b3","#ffffff","#0a1530","#070f24","#1a2a52","#005bab","#dd5b00","#793400","#ff64c8"];
const title = "Notion";
const description = "All-in-one workspace. Warm minimalism, serif headings, soft surfaces.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
