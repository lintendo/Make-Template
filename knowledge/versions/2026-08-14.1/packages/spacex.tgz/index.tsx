import React from 'react';
import './style.css';

const colors = ["#000000","#ffffff","#f0f0fa","#0a0a0a","#3a3a3f","#e0e0e8","#0000ee","#5a5a5f","#a0a0a0","#fbbf24","#8a8a8a","#e0e0e0"];
const title = "SpaceX";
const description = "Space technology. Stark black and white, full-bleed imagery, futuristic.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
