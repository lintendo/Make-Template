import React from 'react';
import './style.css';

const colors = ["#07080a","#101111","#0d0d0d","#ffffff","#e8e8e8","#f4f4f6","#000000","#cdcdcd","#d3d3d4","#9c9c9d","#6a6b6c","#434345"];
const title = "Raycast";
const description = "Productivity launcher. Sleek dark chrome, vibrant gradient accents.";

export default function ThemePreview() {
  return (
    <main className="axhub-theme-package">
      <section className="axhub-theme-package__card">
        <p className="axhub-theme-package__eyebrow">Design Knowledge</p>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="axhub-theme-package__palette" aria-label="Theme palette">
          {colors.map((color) => (
            <span key={color} title={color} style={{ backgroundColor: color }} />
          ))}
        </div>
      </section>
    </main>
  );
}
